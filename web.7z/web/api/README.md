# Web Api

To start, run the command `npm install` and `npm start`
Data will be available at GET requests on http://127.0.0.1:6789/api/tweets/DatabaseCollection?limit=100&page=100